document.addEventListener("DOMContentLoaded", function() {
  renderMathInElement(document.body);
});

window.onclick = e => {
    if (e.target.tagName == "IMG" && e.target.parentNode.title == "external-links") {
        e.target.parentNode.setAttribute("target", "_blank");
    }
}

let links = [...document.links].forEach((link) => {
  if (link.hostname != window.location.hostname) {
    link.target = '_blank'
  }
})